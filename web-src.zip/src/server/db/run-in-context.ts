import type { Prisma } from "@/generated/prisma/client";
import type { DbClient } from "./create-client";

/**
 * Framework-free core of the RLS context helpers (also used by integration tests with
 * their own client). Kept separate from ./context.ts so it has no "server-only" import.
 */

export type DbContext = {
  userId?: string | null;
  gymId?: string | null;
  supportSessionId?: string | null;
  platformAdmin?: boolean;
  /** Member app requests only; the database re-validates it (app_current_member_id()). */
  memberId?: string | null;
  /** A member's booking action (see app_is_member_action()); only with a verified memberId. */
  memberAction?: boolean;
};

export type Tx = Prisma.TransactionClient;

export type TxOptions = {
  isolationLevel?: Prisma.TransactionIsolationLevel;
  timeoutMs?: number;
};

export async function runInContext<T>(
  db: DbClient,
  ctx: DbContext,
  fn: (tx: Tx) => Promise<T>,
  options: TxOptions = {}
): Promise<T> {
  return db.$transaction(
    async (tx) => {
      // set_config(..., true) is transaction-local (equivalent to SET LOCAL) and parameterised.
      await tx.$queryRaw`
        SELECT set_config('app.current_user_id', ${ctx.userId ?? ""}, true),
               set_config('app.current_gym_id', ${ctx.gymId ?? ""}, true),
               set_config('app.support_session_id', ${ctx.supportSessionId ?? ""}, true),
               set_config('app.platform_admin', ${ctx.platformAdmin ? "on" : ""}, true),
               set_config('app.current_member_id', ${ctx.memberId ?? ""}, true),
               set_config('app.member_action', ${ctx.memberId && ctx.memberAction ? "on" : ""}, true)`;
      return fn(tx);
    },
    { isolationLevel: options.isolationLevel, timeout: options.timeoutMs ?? 15_000, maxWait: 5_000 }
  );
}
